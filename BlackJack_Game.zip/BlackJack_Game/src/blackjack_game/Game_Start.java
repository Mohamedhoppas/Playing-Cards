/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack_game;

import static blackjack_game.BlackJack_Game.Deck;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Mohamed Adel
 */
public class Game_Start extends JFrame{
    Container cp=getContentPane();
    JButton StartGame=new JButton("Start a new game");
    JButton ShowDetails=new JButton("Details");
    JLabel LB1;
    JLabel LB2=new JLabel("Welcome to BLACK JACK GAME");
    JLabel TOTAL=new JLabel("Total: ");
    String Path;
    JButton HTP=new JButton("How to play");
    Game_Start(){
        
        Deck.add(Path);
        for(int i=1;i<=13;i++){
            Path="C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\Deck\\"+i+" S.png";
            Deck.add(Path);
        }
        
        for(int i=1;i<=13;i++){
            Path="C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\Deck\\"+i+" H.png";
            Deck.add(Path);            
        }
        
        for(int i=1;i<=13;i++){
            Path="C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\Deck\\"+i+" D.png";
            Deck.add(Path);
        }
        
        for(int i=1;i<=13;i++){
            Path="C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\Deck\\"+i+" T.png";
            Deck.add(Path);
        }

        setSize(2000, 1500);
        setTitle("BlackJack");
        setLayout(new FlowLayout());
        
        cp.setBackground(Color.green.darker().darker().darker().darker().darker());
        ImageIcon icon=new ImageIcon("C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\blackjack.jpg");
        setIconImage(icon.getImage());
        
        add(LB2);
        add(StartGame);
        add(ShowDetails);
        add(HTP);
        
        StartGame.addActionListener(new Action());
        ShowDetails.addActionListener(new Action());
        HTP.addActionListener(new Action());

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public class Action implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
          if(ae.getSource()==StartGame)
          {
           NewGame gameMode=new NewGame();
          }
          else if (ae.getSource()==ShowDetails)
          {
              JOptionPane.showMessageDialog(null, "This game is created by Mohamed Adel." );
              
          }
          else if (ae.getSource()==HTP){
               JOptionPane.showMessageDialog(null,"The object of this game is to get 21 POINTS or to try to reach to it by getting random card but if you passed 21 you lose.");
              JOptionPane.showMessageDialog(null,"*~ ~ ~ RULE ~ ~ ~ * "+" Points: 1-->10 Normal points ~ J->11 ~ Q->12 ~ K->0");
          }
        
    }
}
        public void paint(Graphics g){
    super.paint(g);
        try {
            BufferedImage img=ImageIO.read(new File("C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\BJ.png"));
            g.drawImage(img, 200, 75,1500 , 900, null);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
}
