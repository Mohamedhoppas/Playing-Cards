/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack_game;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Mohamed Adel
 */
public class BlackJack_Game {
 static public ArrayList<String>Deck=new ArrayList();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Game_Start game=new Game_Start();
    
        
    }
    
}
