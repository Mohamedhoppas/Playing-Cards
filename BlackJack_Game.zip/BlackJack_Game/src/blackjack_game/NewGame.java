/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack_game;

import static blackjack_game.BlackJack_Game.Deck;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Mohamed Adel
 */
public class NewGame extends JFrame{

    Random random=new Random ();
    int NumRandom;
    Container cp=getContentPane();
    CardForm CF=new CardForm();
    JButton Hit=new JButton("Hit");
    JButton Stand=new JButton("Stand");
    JLabel TOTAL=new JLabel("Total: ");
    JLabel Bank_Amount=new JLabel("BANK Amount: "+CF.getAmount()+"$ ");
    JLabel Chance=new JLabel();
    ImageIcon imgBit;
    NewGame(){
        setSize(2000, 1500);
        setTitle("Game Mode");
        cp.setBackground(Color.GREEN.darker().darker());
        setLayout(new FlowLayout());
        add(Hit);
        add(Stand);
        add(TOTAL);
        add(Bank_Amount);
        
        Stand.addActionListener(new Action());
        Hit.addActionListener(new Action());
        
        setVisible(true);

        
    }
    public class Action implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {

            if(ae.getSource()==Hit){
            NumRandom=random.nextInt(51)+1;
            if(CF.getTotal()<21){
                imgBit =new ImageIcon(Deck.get(NumRandom));  
                NumRandom=random.nextInt(51)+1;
                CF.setTotal(CF.getTotal()+(NumRandom%13));
                Chance.setIcon(new ImageIcon(new ImageIcon(Deck.get(NumRandom)).getImage().getScaledInstance(CF.getArd(), CF.getTool(),Image.SCALE_DEFAULT)));
                add(Chance);
                CF.setSum(CF.getTotal());
                TOTAL.setText("TOTAL: "+CF.getSum());     
            }
            else
                JOptionPane.showMessageDialog(null, "You passed 21, Sorry you lost press Stand Button to finish the game");
                           
            }
            else if (ae.getSource()==Stand){
                
                if(CF.getSum()==21){
                    JOptionPane.showMessageDialog(null, "CONGRATULATION BLACKJACK... YOU WIN 500 $");
                     CF.setAmount(CF.getAmount()+500);
                }
                else if (CF.getSum()>21){
                    JOptionPane.showMessageDialog(null, "SORRY... YOU LOST 200$");
                     CF.setAmount(CF.getAmount()-200); 
                }
                else if (CF.getSum()==20){
                    JOptionPane.showMessageDialog(null, "CONGRATULATION... YOU WIN 300 $");
                     CF.setAmount(CF.getAmount()+300);
                }
                else if (CF.getSum()==19){
                    JOptionPane.showMessageDialog(null, "CONGRATULATION... YOU WIN 200 $");
                     CF.setAmount(CF.getAmount()+200);
                }
                else{
                    JOptionPane.showMessageDialog(null, "SORRY... YOU LOST 100$");  
                    CF.setAmount(CF.getAmount()-100); 
                }
                Bank_Amount.setText("BANK Amount: "+CF.getAmount());
               
                JOptionPane.showMessageDialog(null, "Thankyou, hope you enjoyed the game");  
                
                      Game_Start newGame=new Game_Start();
              
            }   
        }        
    }
    
    
       public void paint (Graphics g) {
           super.paint(g);
                   
               try {
                   
                   BufferedImage img =ImageIO.read(new File("C:\\Users\\Mohamed Adel\\Desktop\\BlackJack\\blackjacktable.jpg"));
                   g.drawImage(img, 220, 165,1500 , 870, null);                
                   
               } catch (IOException ex) {
                   JOptionPane.showMessageDialog(null, ex);
               }    
               
               
               for(int i =0;i<2;i++){
               NumRandom=random.nextInt(52);
                  
               try {
                   
                   BufferedImage img =ImageIO.read(new File(Deck.get(NumRandom)));
                   g.drawImage(img, CF.getPos_x(), CF.getPos_y(), CF.getArd(), CF.getTool(), null);
                   CF.setPos_x(CF.getPos_x()+50);
                   CF.setTotal(CF.getTotal()+(NumRandom%13));
                   
                   
               } catch (IOException ex) {
                   JOptionPane.showMessageDialog(null, ex);
               }                   
                   }
           
           CF.setSum(CF.getTotal());
           TOTAL.setText("TOTAL: "+CF.getSum());
       }
}
