/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack_game;

/**
 *
 * @author Mohamed Adel
 */
public class CardForm {
    private int pos_x=400;
    private int pos_y=900;
    private int Tool=100;
    private int Ard=100;
    private int Sum=0;
    private int amount=500;
    private int Total=0;

    public int getTotal() {
        return Total;
    }

    public void setTotal(int Total) {
        this.Total = Total;
    }
    
    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    CardForm(){
    pos_x=900;
    pos_y=800;
    Tool=100;
    Ard=100;
    Sum=0;
    }
    
    public int getSum() {
        return Sum;
    }

    public void setSum(int Sum) {
        this.Sum = Sum;
    }
    

    public int getPos_x() {
        return pos_x;
    }

    public void setPos_x(int pos_x) {
        this.pos_x = pos_x;
    }

    public int getPos_y() {
        return pos_y;
    }

    public void setPos_y(int pos_y) {
        this.pos_y = pos_y;
    }

    public int getTool() {
        return Tool;
    }

    public void setTool(int Tool) {
        this.Tool = Tool;
    }

    public int getArd() {
        return Ard;
    }

    public void setArd(int Ard) {
        this.Ard = Ard;
    }
    
    
}
